// ======================================
// 🔒 PASSWORD PROTECTION SYSTEM
// ======================================
document.addEventListener("DOMContentLoaded", () => {
  const lockScreen = document.getElementById("lockScreen");
  const lockedContainer = document.getElementById("lockedContainer");
  const unlockBtn = document.getElementById("unlockBtn");
  const errorMsg = document.getElementById("errorMsg");
  // ===============================
// 🔥 SECRET SHORTCUT: CTRL + X
// ===============================
document.addEventListener("keydown", (e) => {
  if (e.ctrlKey && e.key.toLowerCase() === "x") {
    // Auto unlock
    lockScreen.style.display = "none";
    lockedContainer.style.display = "block";
    initExtension();
  }
});


  unlockBtn.addEventListener("click", () => {
    const pass = document.getElementById("passwordInput").value;

    if (pass === "omkore@2003") {
      lockScreen.style.display = "none";
      lockedContainer.style.display = "block";
      initExtension(); // Load extension features after unlock
    } else {
      errorMsg.style.display = "block";
      shake(lockScreen);
    }
  });
});

// Shake animation for wrong password
function shake(el) {
  el.style.animation = "shake 0.2s";
  setTimeout(() => (el.style.animation = ""), 300);
}

// ======================================
// MAIN EXTENSION FEATURE BOOTSTRAP
// (NO DOMContentLoaded inside!)
// ======================================
async function initExtension() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  chrome.scripting.executeScript(
    {
      target: { tabId: tab.id },
      function: getPresentStudents,
    },
    (results) => {
      if (!results || !results[0]) return;

      const students = results[0].result || [];
      const studentList = document.getElementById("studentList");

      document.getElementById("studentCount").textContent = students.length;

      students.forEach((s) => {
        const div = document.createElement("div");
        div.className = "student-item";

        div.innerHTML = `
          <span>${s.name}</span>
          <label class="switch">
            <input type="checkbox" class="present-toggle student-check" data-id="${s.href}" checked>
            <span class="slider"></span>
          </label>
        `;

        studentList.appendChild(div);
      });

      // -------------------------------
      // 🔎 SEARCH FILTER — LIVE FILTERING
      // -------------------------------
      const searchInput = document.getElementById("searchInput");

      searchInput.addEventListener("input", () => {
        const query = searchInput.value.toLowerCase();

        document.querySelectorAll(".student-item").forEach((item) => {
          const name = item.querySelector("span").textContent.toLowerCase();
          item.style.display = name.includes(query) ? "flex" : "none";
        });
      });

      // SELECT ALL
      const selectAllToggle = document.getElementById("selectAllToggle");
      selectAllToggle.addEventListener("change", () => {
        const allChecks = document.querySelectorAll(".student-check");
        allChecks.forEach((ch) => (ch.checked = selectAllToggle.checked));
      });

      // APPROVE SELECTED
      document.getElementById("approveBtn").addEventListener("click", () => {
        const selectedUrls = Array.from(
          document.querySelectorAll(".student-check:checked")
        ).map((el) => el.dataset.id);

        chrome.scripting.executeScript({
          target: { tabId: tab.id },
          function: approveSelectedStudents,
          args: [selectedUrls],
        });
      });

      // REJECT SELECTED
      document.getElementById("rejectBtn").addEventListener("click", () => {
        const selectedUrls = Array.from(
          document.querySelectorAll(".student-check:checked")
        ).map((el) => el.dataset.id);

        chrome.scripting.executeScript({
          target: { tabId: tab.id },
          function: rejectSelectedStudents,
          args: [selectedUrls],
        });
      });
    }
  );
}

// ======================================
// ORIGINAL FUNCTIONS—NO CHANGES NEEDED
// ======================================
function getPresentStudents() {
  const rows = document.querySelectorAll(
    "#DataTables_Table_0 > tbody > tr > td:nth-child(2)"
  );

  return Array.from(rows).map((el) => {
    const btn = el.closest("tr").querySelector("a.btn-success");

    return {
      name: el.textContent.trim(),
      href: btn?.href || null,
    };
  });
}

function approveSelectedStudents(selectedHrefs) {
  document.querySelectorAll("a.btn-success").forEach((btn) => {
    if (selectedHrefs.includes(btn.href)) {
      fetch(btn.href).catch(() => {});
    }
  });

  setTimeout(() => location.reload(), 2000);
}

function rejectSelectedStudents(selectedHrefs) {
  selectedHrefs.forEach((url) => {
    if (!url) return;

    const rejectUrl = url.replace("action=Yes", "action=No");
    fetch(rejectUrl).catch(() => {});
  });

  setTimeout(() => location.reload(), 2000);
}
